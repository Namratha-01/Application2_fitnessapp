package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LogWorkoutActivity : AppCompatActivity() {

    private lateinit var workoutTypeSpinner: Spinner
    private lateinit var saveWorkoutButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_workout)

        workoutTypeSpinner = findViewById(R.id.workoutTypeSpinner)
        saveWorkoutButton = findViewById(R.id.saveWorkoutButton)

        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.workout_types,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        workoutTypeSpinner.adapter = adapter

        workoutTypeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val workoutType = parent?.getItemAtPosition(position).toString()
                Toast.makeText(parent?.context, "Selected: $workoutType", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        saveWorkoutButton.setOnClickListener {
            val selectedWorkout = workoutTypeSpinner.selectedItem.toString()
            Toast.makeText(this@LogWorkoutActivity, "Workout Saved: $selectedWorkout", Toast.LENGTH_SHORT).show()
        }
    }
}
