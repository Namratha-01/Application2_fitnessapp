package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var addWorkoutButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        addWorkoutButton = findViewById(R.id.addWorkoutButton)
        addWorkoutButton.setOnClickListener {
            val intent = Intent(this@MainActivity, LogWorkoutActivity::class.java)
            startActivity(intent)
        }
    }
}